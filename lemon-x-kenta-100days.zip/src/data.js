export const TIMELINE = [
  { date: "Day 1", title: "We Started Talking 💬", desc: "The very first chat that started everything." },
  { date: "Day 21", title: "Confession Day ❤️", desc: "The day Kenta told Lemon she’s his everything." },
  { date: "Day 50", title: "Inside Jokes 😝", desc: "Spammed Kentaaa and Nothing 🙈🥰 until both laughed their ass off." },
  { date: "Day 100", title: "100 Days Strong ✨", desc: "Celebrating love, memories, and the promise of forever." }
];

export const GALLERY = [
  { src: "https://placekitten.com/300/200", caption: "Our silly selfie 😆" },
  { src: "https://picsum.photos/300/200", caption: "Funny meme we shared 😂" },
  { src: "https://placekitten.com/301/200", caption: "That random chat screenshot 💬" },
  { src: "https://picsum.photos/301/200", caption: "A cute doodle I made 🎨" }
];

export const CHATS = [
  { from: "Lemon", text: "Kentaaa 😝" },
  { from: "Kenta", text: "Yes, my lemon? 🍋" },
  { from: "Lemon", text: "Nothing 🙈🥰" },
  { from: "Kenta", text: "Bruhh you drive me crazy with that! 💛" }
];